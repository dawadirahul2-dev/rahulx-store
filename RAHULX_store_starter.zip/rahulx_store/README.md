# RAHULX e-commerce starter

This project keeps the **storefront in one `index.html`**. Supabase provides the database, authentication, image storage and access control. A Supabase Edge Function validates checkout, creates the order atomically and sends the email through Resend.

## Files
- `index.html` — responsive storefront, cart, checkout and admin UI.
- `schema.sql` — database tables, RLS, stock-safe checkout RPC and storage policies.
- `supabase/functions/place-order/index.ts` — server-side order submission and email notification.

## 1. Create Supabase project
1. Create a project at https://supabase.com and open **SQL Editor**.
2. Run all of `schema.sql`.
3. Open **Project Settings → API**. Copy Project URL and `anon`/publishable key.
4. In `index.html`, replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`. The anon key is designed to be public; never use the `service_role` key in the page.
5. In **Authentication → Providers**, keep Email enabled. Under Authentication settings, disable public sign-ups after you create your own admin user (or otherwise restrict account creation). Create your admin account under **Authentication → Users**.
6. Copy that user's UUID. Replace the placeholder UUID in the final commented SQL statement in `schema.sql`, uncomment it and run:
   `insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');`
   Only this allow-listed Auth user receives admin permissions. Do not share the account.
7. In Authentication URL configuration, add your deployed Netlify URL to Site URL and Redirect URLs.

## 2. Deploy the email / checkout function
Install the Supabase CLI and log in, then from this folder:
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY RESEND_API_KEY=re_xxxxxxxxx
supabase functions deploy place-order --no-verify-jwt
```
The service-role key is used only inside this server-side function to read the newly-created order lines for the email; never place it in `index.html`. The function is intentionally callable by customers without a login; its database RPC validates all customer data, current product prices, product availability and stock in one transaction. Do not put the Resend key in `index.html`.
In `index.ts`, replace `orders@YOUR_VERIFIED_DOMAIN` with a sender address on a domain you verified in Resend. Set the recipient remains `dawadirahul2@gmail.com`.
Create a Resend account at https://resend.com, verify a domain you control, and create an API key. For initial testing, use a sender address permitted by your Resend account. Email delivery will not work until a verified sender/domain and secret are configured.

## 3. Run and deploy the site
- For local testing, serve this folder with a local static server (for example `python -m http.server 8000`) and open `http://localhost:8000`. Direct file-open may work for browsing, but a local server is more reliable.
- Create a Netlify site and deploy `index.html` (drag-and-drop the folder or connect a Git repository). No build command is required.
- Add the Netlify URL to Supabase Auth URL configuration.
- After deployment, open your public website and use the **ADMIN** link. Sign in with the Auth account you created. The dashboard lets you add/edit/delete products, upload up to five images, manage stock, view orders and update order status.

## 4. Add test products
The storefront displays six sample products while Supabase is not configured. For real products, sign into the admin dashboard and add them there. When Supabase is configured, the public catalog comes from the `products` table; the demo catalog is not inserted into your database.

## Important security / production notes
- RLS is enforced by Supabase, not by hiding admin UI. Public visitors can read active products and public product images only. Only the allow-listed authenticated admin can manage products and upload images. Customer orders and order items have no public read/update policies.
- Checkout calls a `SECURITY DEFINER` SQL function that obtains price and stock from the database, locks product rows and decrements stock atomically. The browser does not submit trusted prices or totals.
- The Edge Function sends email using a server-side Resend secret. If email delivery fails, the order remains saved and the function returns `email_sent: false`; check Supabase Function logs and Resend logs.
- This is a starter, not a complete audited commerce platform. Before accepting significant sales, add rate limiting / bot protection (e.g. Turnstile), stronger phone/email validation, shipping/tax rules, image cleanup when replacing photos, backups, monitoring, and a tested refund/cancellation workflow. The current admin status update does not automatically restock cancelled orders; handle stock adjustments deliberately.
- Admin order/customer data is private under RLS. Keep your Supabase project secure, use a strong unique password and enable MFA where available.
