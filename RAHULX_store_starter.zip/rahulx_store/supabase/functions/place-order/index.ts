// Supabase Edge Function: supabase/functions/place-order/index.ts
// Secrets required: SUPABASE_URL, SUPABASE_ANON_KEY, RESEND_API_KEY
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405, headers: cors });
  try {
    const { customer, items } = await req.json();
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendKey = Deno.env.get("RESEND_API_KEY");
    const supabase = createClient(url, anon, { auth: { persistSession: false } });
    const { data: orderId, error } = await supabase.rpc("create_customer_order", {
      p_customer: customer,
      p_items: items,
    });
    if (error) throw new Error(error.message);

    // Email is sent server-side. A mail failure does not undo a successfully placed order.
    let emailSent = false;
    if (resendKey) {
      const adminClient = createClient(url, serviceRole, { auth: { persistSession: false } });
      const { data: lines } = await adminClient.from("order_items")
        .select("product_name,size,quantity,unit_price")
        .eq("order_id", orderId);
      const orderText = (lines || []).map((x) =>
        `${x.product_name} | Size ${x.size} | Qty ${x.quantity} | NPR ${x.unit_price}`
      ).join("\n");
      const amount = (lines || []).reduce((sum, x) => sum + Number(x.unit_price) * x.quantity, 0);
      const mail = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "RAHULX Orders <orders@YOUR_VERIFIED_DOMAIN>",
          to: ["dawadirahul2@gmail.com"],
          subject: `New RAHULX order ${orderId}`,
          text: `New order received\n\nOrder: ${orderId}\nCustomer: ${customer.name}\nPhone: ${customer.phone}\nEmail: ${customer.email}\nAddress: ${customer.address}\n\nItems:\n${orderText}\n\nTotal: NPR ${amount}\nOrder date: ${new Date().toISOString()}`,
        }),
      });
      emailSent = mail.ok;
      if (!mail.ok) console.error("Resend email failed:", await mail.text());
    } else {
      console.error("RESEND_API_KEY is not configured; order stored but email not sent.");
    }
    return Response.json({ order_id: orderId, email_sent: emailSent }, { headers: cors });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Unable to place order" }, { status: 400, headers: cors });
  }
});
