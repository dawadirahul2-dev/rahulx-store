-- RAHULX Supabase schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_store_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.admin_users where user_id = auth.uid());
$$;
revoke all on function public.is_store_admin() from public;
grant execute on function public.is_store_admin() to authenticated;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  description text not null default '',
  category text not null check (category in ('T-shirts','Hoodies','Jackets','Pants','Jeans','Sneakers')),
  price numeric(12,2) not null check (price > 0),
  sizes jsonb not null default '{}'::jsonb,
  images text[] not null default '{}',
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.products enable row level security;
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products for select using (active = true or public.is_store_admin());
drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products for all to authenticated using (public.is_store_admin()) with check (public.is_store_admin());

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  email text not null,
  address text not null,
  total numeric(12,2) not null check (total >= 0),
  status text not null default 'pending' check (status in ('pending','confirmed','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  size text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price > 0)
);
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
drop policy if exists "Admins read and update orders" on public.orders;
create policy "Admins read and update orders" on public.orders for all to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
drop policy if exists "Admins read order items" on public.order_items;
create policy "Admins read order items" on public.order_items for select to authenticated using (public.is_store_admin());
-- No anon policies on orders/order_items: customers cannot read or alter private orders.

-- Atomic checkout. Prices and stock are looked up from the database, never trusted from browser totals.
create or replace function public.create_customer_order(
  p_customer jsonb,
  p_items jsonb
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid := gen_random_uuid();
  v_total numeric(12,2) := 0;
  v_item jsonb;
  v_product public.products%rowtype;
  v_size text;
  v_qty integer;
  v_available integer;
begin
  if jsonb_typeof(p_customer) <> 'object' or jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 30 then
    raise exception 'Invalid order details';
  end if;
  if length(trim(coalesce(p_customer->>'name',''))) not between 2 and 100
     or length(trim(coalesce(p_customer->>'phone',''))) not between 6 and 25
     or length(trim(coalesce(p_customer->>'email',''))) not between 5 and 150
     or length(trim(coalesce(p_customer->>'address',''))) not between 5 and 500 then
    raise exception 'Please provide valid customer details';
  end if;

  -- Lock each product row while validating/decrementing stock.
  for v_item in select value from jsonb_array_elements(p_items) loop
    if coalesce(v_item->>'product_id','') !~* '^[0-9a-f-]{36}$' then
      raise exception 'Invalid product';
    end if;
    v_size := trim(coalesce(v_item->>'size',''));
    v_qty := (v_item->>'quantity')::integer;
    if v_size = '' or v_qty < 1 or v_qty > 20 then raise exception 'Invalid size or quantity'; end if;
    select * into v_product from public.products where id=(v_item->>'product_id')::uuid and active=true for update;
    if not found then raise exception 'A product is no longer available'; end if;
    v_available := coalesce((v_product.sizes->>v_size)::integer,0);
    if v_available < v_qty then raise exception 'Insufficient stock for % (%)',v_product.name,v_size; end if;
    v_total := v_total + v_product.price * v_qty;
  end loop;

  insert into public.orders(id,customer_name,phone,email,address,total)
  values(v_order_id,trim(p_customer->>'name'),trim(p_customer->>'phone'),trim(p_customer->>'email'),trim(p_customer->>'address'),v_total);

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_size := trim(v_item->>'size'); v_qty := (v_item->>'quantity')::integer;
    select * into v_product from public.products where id=(v_item->>'product_id')::uuid for update;
    v_available := coalesce((v_product.sizes->>v_size)::integer,0);
    update public.products set sizes=jsonb_set(sizes,array[v_size],to_jsonb(v_available-v_qty),true),updated_at=now() where id=v_product.id;
    insert into public.order_items(order_id,product_id,product_name,size,quantity,unit_price)
    values(v_order_id,v_product.id,v_product.name,v_size,v_qty,v_product.price);
  end loop;
  return v_order_id;
end;
$$;
revoke all on function public.create_customer_order(jsonb,jsonb) from public;
grant execute on function public.create_customer_order(jsonb,jsonb) to anon, authenticated;

-- Storage bucket: public image delivery, admin-only uploads/changes/deletes.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=true,file_size_limit=5242880,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "Public read product images" on storage.objects;
create policy "Public read product images" on storage.objects for select using (bucket_id='product-images');
drop policy if exists "Admins upload product images" on storage.objects;
create policy "Admins upload product images" on storage.objects for insert to authenticated with check (bucket_id='product-images' and public.is_store_admin());
drop policy if exists "Admins update product images" on storage.objects;
create policy "Admins update product images" on storage.objects for update to authenticated using (bucket_id='product-images' and public.is_store_admin()) with check (bucket_id='product-images' and public.is_store_admin());
drop policy if exists "Admins delete product images" on storage.objects;
create policy "Admins delete product images" on storage.objects for delete to authenticated using (bucket_id='product-images' and public.is_store_admin());

-- Add the first admin only AFTER creating your user in Authentication > Users.
-- Replace the UUID below with your own Auth user UUID, then run:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');
